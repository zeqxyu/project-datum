export const account_data = {
    "first_name": "Janez",
    "last_name": "Novak",
    "username": "jannov1",

    "email": "janez.novak@gmail.com",
    "phone": "+38664198123",
    "snapchat": "jnovv12",

    "class_name": "1.A",
    "class_code": "1a24",
    
    "status": true,
    "is_president": true,

    "money": 1350,
    "justice_coefficient": 0.86,
}